package com.csse.common;

import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class EmployeeQueryUtility extends BaseUtility {


	public static final String QUERY = "query";
	public static final String ID = "id";

	public static String getEmployeeQueryById(String id) throws Exception {
		NodeList nodeList;
		Element element = null;
		nodeList = DocumentBuilderFactory.newInstance().newDocumentBuilder()
				.parse(new File(Constants.SRC_COM_CSSE_CONFIG_EMPLOYEE_QUERY_XML))
				.getElementsByTagName(QUERY);
		for (int x = 0; x < nodeList.getLength(); x++) {
			element = (Element) nodeList.item(x);
			if (element.getAttribute(ID).equals(id))
				break;
		}

		return element.getTextContent().trim();
	}
}
