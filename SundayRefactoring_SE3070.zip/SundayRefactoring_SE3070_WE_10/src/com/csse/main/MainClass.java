package com.csse.main;


import com.csse.service.EmployeeService;

public class MainClass {



	public static void main(String[] args) {

		EmployeeService employeeService = EmployeeService.getInstance();
		employeeService.displayEmployeesTableTemplateMethod();
	}
}
